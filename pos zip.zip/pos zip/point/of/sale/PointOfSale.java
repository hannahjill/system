package point.of.sale;

public class PointOfSale {

    public static void main(String[] args) {
        posHNJ pos = new posHNJ();
        pos.setVisible(true);
        
}
}
 